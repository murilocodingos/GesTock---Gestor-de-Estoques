// DOM Elements
const circles = document.querySelectorAll(".circle");
const progressBar = document.querySelector(".indicator");

let currentStep = 1;

// Function that updates the current step and updates the DOM
const updateSteps = (index) => {
    currentStep = index + 1;

    // Loop through all circles and add/remove "active" class based on their index and current step
    circles.forEach((circle, i) => {
        circle.classList[i < currentStep ? "add" : "remove"]("active");
    });

    // Update progress bar width based on current step
    progressBar.style.width = `${((currentStep - 1) / (circles.length - 1)) * 100}%`;

    // Disable all circles that come after the current step
    circles.forEach((circle, i) => {
        if (i >= currentStep) {
            circle.classList.remove("active");
        }
    });
};

// Add click event listeners to all circles
circles.forEach((circle, index) => {
    circle.addEventListener("click", () => {
        updateSteps(index);
    });
});